
UBACIVANJE:

1. Zameni fajl:
src/AIsecenjePreview.jsx

2. U Supabase:
- SQL Editor
- pokreni fajl supabase/planovi_secenja.sql

3. Proveri da tabela "magacin" ima kolone:
- id
- metraza
- status

GOTOVO
